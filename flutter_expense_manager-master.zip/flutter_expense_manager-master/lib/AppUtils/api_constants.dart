/*
Title: ApiConstant Used through App
Purpose:ApiConstant Used through App
Created On: 01/10/2023
Edited On:01/10/2023
Author: Kalpesh Khandla
*/

class ApiConstant {
  //static String baseURL = "https://floran-expense-tracker.herokuapp.com/api/";
}
