/*
Title: AppFontSize used thorough App
Purpose:AppFontSize used thorough App
Created On: 01/10/2023
Edited On:01/10/2023
Author: Kalpesh Khandla
*/

class AppFontSize {
  static const double fontSize8 = 8;
  static const double fontSize9 = 9;
  static const double fontSize10 = 10;
  static const double fontSize11 = 11;
  static const double fontSize12 = 12;
  static const double fontSize13 = 13;
  static const double fontSize14 = 14;
  static const double fontSize15 = 15;
  static const double fontSize16 = 16;
  static const double fontSize17 = 17;
  static const double fontSize18 = 18;
  static const double fontSize19 = 19;
  static const double fontSize20 = 20;
  static const double fontSize21 = 21;
  static const double fontSize22 = 22;
  static const double fontSize23 = 23;
  static const double fontSize24 = 24;
  static const double fontSize28 = 28;
  static const double fontSize30 = 30;
  static const double fontSize32 = 32;
  static const double fontSize34 = 34;
}
